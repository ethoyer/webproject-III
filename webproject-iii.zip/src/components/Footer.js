import React from "react";

const Footer = () => (
    <footer>
        <p>Webproject III, group 1 | DigitalNorway</p> 
    </footer>
);

export default Footer;
