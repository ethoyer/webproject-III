import React from 'react';
function Error () {
return (
    <div>
        <h1>Nothing to see here</h1>
        <a href="/">Press here to return to homepage</a>
    </div>
    )
} 
export default Error;