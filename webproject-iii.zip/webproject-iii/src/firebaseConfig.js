import * as firebase from 'firebase';
import 'firebase/firestore'

firebase.initializeApp({
  apiKey: "AIzaSyAxM264qthYVjnwJPcMJNYu2nueBAmpY_4",
  authDomain: "web-iii-a91c8.firebaseapp.com",
  databaseURL: "https://web-iii-a91c8.firebaseio.com",
  projectId: "web-iii-a91c8",
  storageBucket: "web-iii-a91c8.appspot.com",
  messagingSenderId: "853961489045",
  appId: "1:853961489045:web:789a743d228cc0b252b99c",
  measurementId: "G-T9LRESEJ1M"
});


let db = firebase.firestore()


export default {
  firebase, db
}